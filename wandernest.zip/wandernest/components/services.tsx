import Link from "next/link"
import { Compass, Lightbulb, Map } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function Services() {
  return (
    <section className="bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title">OUR SERVICES</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="group hover:-translate-y-2 transition-transform duration-300">
            <CardContent className="p-6 text-center">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Compass className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-4">DISCOVER</h3>
              <p className="text-slate-600">DISCOVER THE UNDISCOVERED WITH OUR FELLOW TRAVELLERS</p>
              <Link href="/services/discover" className="text-primary font-medium inline-block mt-4 hover:underline">
                Learn more
              </Link>
            </CardContent>
          </Card>

          <Card className="group hover:-translate-y-2 transition-transform duration-300">
            <CardContent className="p-6 text-center">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lightbulb className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-4">GET INSPIRED</h3>
              <p className="text-slate-600">Inspiration for your next getaway</p>
              <Link href="/services/inspiration" className="text-primary font-medium inline-block mt-4 hover:underline">
                Learn more
              </Link>
            </CardContent>
          </Card>

          <Card className="group hover:-translate-y-2 transition-transform duration-300">
            <CardContent className="p-6 text-center">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Map className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-4">ITINERARY ADVISOR</h3>
              <p className="text-slate-600">
                USE OUR AI-BASED TRIP ADVISOR/ITINERARY WAVE PERSONALISED SPECIALTY FOR YOU
              </p>
              <Link href="/itinerary-advisor" className="text-primary font-medium inline-block mt-4 hover:underline">
                Learn more
              </Link>
            </CardContent>
          </Card>
        </div>
        <div className="text-center mt-10">
          <Button asChild>
            <Link href="/services">View all</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
