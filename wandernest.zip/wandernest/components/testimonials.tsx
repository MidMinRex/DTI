import { Quote } from "lucide-react"

export default function Testimonials() {
  return (
    <section className="bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title">What Our Travelers Say</h2>
        <div className="max-w-3xl mx-auto text-center">
          <div className="flex justify-center mb-6">
            <Quote className="h-12 w-12 text-primary/30" />
          </div>
          <p className="text-lg md:text-xl italic text-slate-700 mb-6">
            A truly wonderful experience. Brilliant for anyone looking to get away from the hustle and bustle of city
            life or detox from their tech for a few days. I could have stayed another week! They really have thought
            about everything here down to the finest details.
          </p>
          <div className="text-slate-500">01 Jan 2023</div>
          <div className="mt-4 flex justify-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-primary"></div>
            <div className="w-3 h-3 rounded-full bg-slate-200"></div>
            <div className="w-3 h-3 rounded-full bg-slate-200"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
