import Link from "next/link"

export default function Footer() {
  const footerLinks = [
    {
      title: "About us",
      links: [
        { label: "Our story", href: "/about/story" },
        { label: "Why us", href: "/about/why-us" },
        { label: "How it works", href: "/about/how-it-works" },
        { label: "FAQ", href: "/faq" },
      ],
    },
    {
      title: "Our cabins",
      links: [
        { label: "North of London", href: "/cabins/north-london" },
        { label: "Golden Hideaway", href: "/cabins/golden-hideaway" },
        { label: "Oak Treehouse", href: "/cabins/oak-treehouse" },
        { label: "AccelG Retreat", href: "/cabins/accelg-retreat" },
        { label: "Blue Lagoon", href: "/cabins/blue-lagoon" },
        { label: "South of London", href: "/cabins/south-london" },
        { label: "Lovenden Retract", href: "/cabins/lovenden-retract" },
        { label: "Butterfly Treehouse", href: "/cabins/butterfly-treehouse" },
        { label: "Mohogany Hideaway", href: "/cabins/mohogany-hideaway" },
      ],
    },
    {
      title: "Get inspired",
      links: [
        { label: "Explore nature", href: "/inspiration/nature" },
        { label: "Hiking trails", href: "/inspiration/hiking" },
        { label: "Swimming", href: "/inspiration/swimming" },
        { label: "Boating", href: "/inspiration/boating" },
        { label: "Rest, relax and re-set", href: "/inspiration/relax" },
        { label: "Pet friendly", href: "/inspiration/pet-friendly" },
      ],
    },
    {
      title: "Support",
      links: [
        { label: "Help", href: "/support/help" },
        { label: "Contact us", href: "/support/contact" },
        { label: "Privacy Policy", href: "/legal/privacy" },
        { label: "Terms of Service", href: "/legal/terms" },
        { label: "Complaints Policy", href: "/legal/complaints" },
      ],
    },
  ]

  return (
    <footer className="bg-slate-800 text-white pt-16 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {footerLinks.map((column, index) => (
            <div key={index}>
              <h3 className="text-lg font-bold mb-4">{column.title}</h3>
              <ul className="space-y-2">
                {column.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link href={link.href} className="text-slate-300 hover:text-white transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="text-center pt-8 border-t border-slate-700">
          <div className="text-2xl font-bold text-primary mb-4">WANDERNEST</div>
          <p className="text-slate-400">&copy; {new Date().getFullYear()} Wandernest. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
