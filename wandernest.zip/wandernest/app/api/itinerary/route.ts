import { NextResponse } from "next/server"
import { fetchWeatherData, fetchHolidays, fetchTravelAdvisory, geocodeLocation } from "@/lib/api-utils"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { destination, startDate, endDate, travelers, interests, budget, accommodation, additionalInfo } = body

    // Calculate number of days
    const start = new Date(startDate)
    const end = new Date(endDate)
    const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))

    // Enhanced itinerary generation with API data
    const itinerary = await generateEnhancedItinerary(body, days)

    return NextResponse.json({
      success: true,
      itinerary,
    })
  } catch (error) {
    console.error("Itinerary generation error:", error)
    return NextResponse.json({ success: false, message: "Failed to generate itinerary" }, { status: 500 })
  }
}

async function generateEnhancedItinerary(preferences: any, days: number) {
  const { destination, startDate, endDate, travelers, interests, budget, accommodation } = preferences

  // Initialize the itinerary object
  const itinerary = {
    destination,
    dates: `${formatDate(new Date(startDate))} - ${formatDate(new Date(endDate))}`,
    travelers,
    days: [] as any[],
    weatherSummary: null as any,
    travelAdvisory: null as any,
    localEvents: [] as any[],
  }

  try {
    // Get geocoded location data
    const geoData = await geocodeLocation(destination)

    // Fetch weather data if geocoding was successful
    let weatherData = null
    if (geoData) {
      weatherData = await fetchWeatherData(`${geoData.lat},${geoData.lng}`, Math.min(days, 7))

      if (weatherData) {
        itinerary.weatherSummary = {
          current: {
            temp_c: weatherData.current.temp_c,
            condition: weatherData.current.condition.text,
            humidity: weatherData.current.humidity,
            wind_kph: weatherData.current.wind_kph,
            precip_mm: weatherData.current.precip_mm,
          },
          forecast: weatherData.forecast.forecastday.map((day: any) => ({
            date: day.date,
            maxtemp_c: day.day.maxtemp_c,
            mintemp_c: day.day.mintemp_c,
            condition: day.day.condition.text,
            daily_chance_of_rain: day.day.daily_chance_of_rain,
          })),
        }
      }
    }

    // Fetch travel advisory for India
    const travelAdvisory = await fetchTravelAdvisory("IN")
    if (travelAdvisory && travelAdvisory.data && travelAdvisory.data.IN) {
      itinerary.travelAdvisory = {
        score: travelAdvisory.data.IN.advisory.score,
        message: travelAdvisory.data.IN.advisory.message,
        updated: travelAdvisory.data.IN.advisory.updated,
        source: travelAdvisory.data.IN.advisory.source,
      }
    }

    // Fetch holidays/events
    const currentYear = new Date().getFullYear()
    const holidays = await fetchHolidays("IN", currentYear)
    if (holidays) {
      // Filter holidays that occur during the trip
      const tripStart = new Date(startDate)
      const tripEnd = new Date(endDate)

      itinerary.localEvents = holidays
        .filter((holiday: any) => {
          const holidayDate = new Date(holiday.date)
          return holidayDate >= tripStart && holidayDate <= tripEnd
        })
        .map((holiday: any) => ({
          name: holiday.name,
          localName: holiday.localName,
          date: holiday.date,
          type: holiday.types.join(", "),
        }))
    }

    // Generate activities for each day with enhanced data
    for (let i = 0; i < days; i++) {
      const currentDate = new Date(startDate)
      currentDate.setDate(new Date(startDate).getDate() + i)

      // Get weather for this specific day if available
      let dayWeather = null
      if (weatherData && i < weatherData.forecast.forecastday.length) {
        dayWeather = weatherData.forecast.forecastday[i].day
      }

      // Generate activities considering weather
      const dayActivities = await generateDayActivities(
        interests,
        i + 1,
        dayWeather,
        destination,
        budget[0], // Using the first value from budget slider
      )

      // Check if there are any local events/holidays on this day
      const eventsToday = itinerary.localEvents.filter((event: any) => {
        return new Date(event.date).toDateString() === currentDate.toDateString()
      })

      itinerary.days.push({
        day: i + 1,
        date: formatDate(currentDate),
        weather: dayWeather
          ? {
              condition: dayWeather.condition.text,
              maxTemp: dayWeather.maxtemp_c,
              minTemp: dayWeather.mintemp_c,
              chanceOfRain: dayWeather.daily_chance_of_rain,
            }
          : null,
        localEvents: eventsToday,
        activities: dayActivities,
      })
    }

    return itinerary
  } catch (error) {
    console.error("Error in enhanced itinerary generation:", error)
    // Fallback to basic itinerary if API calls fail
    return generateBasicItinerary(preferences, days)
  }
}

function formatDate(date: Date) {
  const options: Intl.DateTimeFormatOptions = { year: "numeric", month: "long", day: "numeric" }
  return date.toLocaleDateString("en-US", options)
}

async function generateDayActivities(
  interests: string[],
  day: number,
  weather: any = null,
  destination: string,
  budgetLevel: number,
) {
  // Sample activities based on common interests
  const activityTypes = {
    "Nature & Outdoors": [
      {
        title: "Hiking Trail Exploration",
        description: "Explore scenic hiking trails with breathtaking views",
        type: "Outdoors",
        weatherSensitive: true,
        budgetLevel: "low",
      },
      {
        title: "National Park Visit",
        description: "Visit a nearby national park and discover local wildlife",
        type: "Outdoors",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
      {
        title: "Beach Day",
        description: "Relax on the beach and enjoy water activities",
        type: "Outdoors",
        weatherSensitive: true,
        budgetLevel: "low",
      },
    ],
    "History & Culture": [
      {
        title: "Museum Tour",
        description: "Visit local museums to learn about the region's history",
        type: "Cultural",
        weatherSensitive: false,
        budgetLevel: "medium",
      },
      {
        title: "Historical Site Visit",
        description: "Explore ancient ruins and historical landmarks",
        type: "Cultural",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
      {
        title: "Cultural Workshop",
        description: "Participate in a workshop to learn traditional crafts",
        type: "Cultural",
        weatherSensitive: false,
        budgetLevel: "high",
      },
    ],
    "Food & Cuisine": [
      {
        title: "Food Tour",
        description: "Sample local delicacies on a guided food tour",
        type: "Food",
        weatherSensitive: false,
        budgetLevel: "medium",
      },
      {
        title: "Cooking Class",
        description: "Learn to prepare traditional dishes with local ingredients",
        type: "Food",
        weatherSensitive: false,
        budgetLevel: "high",
      },
      {
        title: "Fine Dining Experience",
        description: "Enjoy a gourmet meal at a renowned restaurant",
        type: "Food",
        weatherSensitive: false,
        budgetLevel: "high",
      },
    ],
    "Adventure & Sports": [
      {
        title: "Zip-lining Adventure",
        description: "Experience an adrenaline-pumping zip-line course",
        type: "Adventure",
        weatherSensitive: true,
        budgetLevel: "high",
      },
      {
        title: "Water Sports",
        description: "Try kayaking, paddleboarding, or surfing",
        type: "Adventure",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
      {
        title: "Mountain Biking",
        description: "Explore rugged terrain on mountain bikes",
        type: "Adventure",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
    ],
  }

  // India-specific activities based on destination
  const indiaSpecificActivities: Record<string, any[]> = {
    Goa: [
      {
        title: "Beach Hopping in North Goa",
        description: "Visit the famous beaches of Baga, Calangute, and Anjuna",
        type: "Outdoors",
        weatherSensitive: true,
        budgetLevel: "low",
      },
      {
        title: "Old Goa Churches Tour",
        description: "Explore the UNESCO World Heritage churches of Old Goa",
        type: "Cultural",
        weatherSensitive: false,
        budgetLevel: "low",
      },
      {
        title: "Spice Plantation Visit",
        description: "Tour a traditional spice plantation with lunch included",
        type: "Cultural",
        weatherSensitive: false,
        budgetLevel: "medium",
      },
      {
        title: "Dudhsagar Waterfall Trip",
        description: "Take a jeep safari to the magnificent Dudhsagar Falls",
        type: "Adventure",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
      {
        title: "Cruise on Mandovi River",
        description: "Enjoy a sunset cruise with cultural performances",
        type: "Entertainment",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
    ],
    Rajasthan: [
      {
        title: "Fort Tour in Jaipur",
        description: "Visit the majestic Amber Fort and other historical forts",
        type: "Cultural",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
      {
        title: "Desert Safari in Jaisalmer",
        description: "Experience camel rides and overnight camping in the Thar Desert",
        type: "Adventure",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
      {
        title: "City Palace Visit in Udaipur",
        description: "Explore the royal City Palace complex on Lake Pichola",
        type: "Cultural",
        weatherSensitive: false,
        budgetLevel: "medium",
      },
      {
        title: "Traditional Rajasthani Dinner",
        description: "Enjoy authentic Rajasthani cuisine with folk performances",
        type: "Food",
        weatherSensitive: false,
        budgetLevel: "medium",
      },
      {
        title: "Handicraft Shopping in Jodhpur",
        description: "Shop for traditional textiles, pottery, and jewelry",
        type: "Shopping",
        weatherSensitive: false,
        budgetLevel: "variable",
      },
    ],
    Delhi: [
      {
        title: "Old Delhi Food Walk",
        description: "Sample street food delicacies in the lanes of Old Delhi",
        type: "Food",
        weatherSensitive: false,
        budgetLevel: "low",
      },
      {
        title: "Qutub Minar and Humayun's Tomb",
        description: "Visit these UNESCO World Heritage monuments",
        type: "Cultural",
        weatherSensitive: true,
        budgetLevel: "medium",
      },
      {
        title: "Lodhi Gardens Walk",
        description: "Stroll through the beautiful Lodhi Gardens with historic tombs",
        type: "Outdoors",
        weatherSensitive: true,
        budgetLevel: "low",
      },
      {
        title: "Shopping at Dilli Haat",
        description: "Explore handicrafts from all over India at this cultural bazaar",
        type: "Shopping",
        weatherSensitive: false,
        budgetLevel: "medium",
      },
      {
        title: "Evening at India Gate",
        description: "Visit the iconic monument and enjoy street food",
        type: "Sightseeing",
        weatherSensitive: true,
        budgetLevel: "low",
      },
    ],
  }

  // Generate 3-4 activities for the day
  const activities = []
  const times = ["9:00 AM", "12:00 PM", "3:00 PM", "7:00 PM"]
  const durations = ["2 hours", "1.5 hours", "3 hours", "2 hours"]

  // Select activities based on interests or default to a mix
  const selectedInterests = interests && interests.length > 0 ? interests : Object.keys(activityTypes)

  // Check if we have specific activities for this destination
  const destinationKey = Object.keys(indiaSpecificActivities).find((key) =>
    destination.toLowerCase().includes(key.toLowerCase()),
  )

  const destinationActivities = destinationKey ? indiaSpecificActivities[destinationKey] : []

  // Weather-based activity filtering
  const isRainy =
    weather &&
    (weather.condition.toLowerCase().includes("rain") ||
      weather.condition.toLowerCase().includes("shower") ||
      weather.daily_chance_of_rain > 60)

  const isHot = weather && weather.maxtemp_c > 35
  const isCold = weather && weather.maxtemp_c < 10

  // Budget level mapping
  const budgetMapping: Record<number, string> = {
    0: "low",
    25: "low",
    50: "medium",
    75: "high",
    100: "luxury",
  }

  // Find closest budget level
  const budgetKeys = Object.keys(budgetMapping).map(Number)
  const closestBudget = budgetKeys.reduce((prev, curr) => {
    return Math.abs(curr - budgetLevel) < Math.abs(prev - budgetLevel) ? curr : prev
  })

  const userBudgetLevel = budgetMapping[closestBudget]

  for (let i = 0; i < 4; i++) {
    let activity

    // Prioritize destination-specific activities
    if (destinationActivities.length > 0 && Math.random() > 0.3) {
      // Use destination-specific activities 70% of the time
      const filteredActivities = destinationActivities.filter((act) => {
        // Filter based on weather conditions
        if (isRainy && act.weatherSensitive) return false

        // Filter based on budget
        if (userBudgetLevel === "low" && act.budgetLevel === "high") return false
        if (userBudgetLevel === "medium" && act.budgetLevel === "luxury") return false

        return true
      })

      if (filteredActivities.length > 0) {
        const activityIndex = Math.floor(Math.random() * filteredActivities.length)
        activity = filteredActivities[activityIndex]
      }
    }

    // Fallback to general activities if no destination-specific activity was selected
    if (!activity) {
      // Rotate through interests for variety
      const interestIndex = (day + i) % selectedInterests.length
      const interestKey =
        selectedInterests[interestIndex] || Object.keys(activityTypes)[i % Object.keys(activityTypes).length]

      // Get activities for this interest
      const interestActivities =
        activityTypes[interestKey as keyof typeof activityTypes] || activityTypes["Nature & Outdoors"]

      // Filter activities based on weather and budget
      const filteredActivities = interestActivities.filter((act) => {
        if (isRainy && act.weatherSensitive) return false

        // Filter based on budget
        if (userBudgetLevel === "low" && act.budgetLevel === "high") return false
        if (userBudgetLevel === "medium" && act.budgetLevel === "luxury") return false

        return true
      })

      // Select an activity
      const activityIndex = Math.floor(Math.random() * filteredActivities.length)
      activity = filteredActivities[activityIndex] || interestActivities[0] // Fallback if filtering removed all options
    }

    // Add weather-appropriate recommendations
    let weatherTip = ""
    if (weather) {
      if (isRainy) {
        weatherTip = "Bring an umbrella or raincoat as rain is expected."
      } else if (isHot) {
        weatherTip = "Stay hydrated and consider indoor activities during peak afternoon heat."
      } else if (isCold) {
        weatherTip = "Dress warmly in layers as temperatures will be cool."
      }
    }

    activities.push({
      time: times[i],
      title: activity.title,
      description: activity.description,
      location: "Local Area",
      duration: durations[i],
      type: activity.type,
      weatherTip: weatherTip,
      budgetCategory: activity.budgetLevel,
    })
  }

  return activities
}

// Fallback function if API calls fail
function generateBasicItinerary(preferences: any, days: number) {
  const { destination, startDate, endDate, travelers, interests } = preferences

  // Generate a simple itinerary based on preferences
  const itinerary = {
    destination,
    dates: `${formatDate(new Date(startDate))} - ${formatDate(new Date(endDate))}`,
    travelers,
    days: [],
  }

  // Generate activities for each day
  for (let i = 0; i < days; i++) {
    const currentDate = new Date(startDate)
    currentDate.setDate(new Date(startDate).getDate() + i)

    const dayActivities = generateBasicDayActivities(interests, i + 1)

    itinerary.days.push({
      day: i + 1,
      date: formatDate(currentDate),
      activities: dayActivities,
    })
  }

  return itinerary
}

function generateBasicDayActivities(interests: string[], day: number) {
  // This is the original function from the previous implementation
  // Sample activities based on common interests
  const activityTypes = {
    "Nature & Outdoors": [
      {
        title: "Hiking Trail Exploration",
        description: "Explore scenic hiking trails with breathtaking views",
        type: "Outdoors",
      },
      {
        title: "National Park Visit",
        description: "Visit a nearby national park and discover local wildlife",
        type: "Outdoors",
      },
      { title: "Beach Day", description: "Relax on the beach and enjoy water activities", type: "Outdoors" },
    ],
    "History & Culture": [
      {
        title: "Museum Tour",
        description: "Visit local museums to learn about the region's history",
        type: "Cultural",
      },
      {
        title: "Historical Site Visit",
        description: "Explore ancient ruins and historical landmarks",
        type: "Cultural",
      },
      {
        title: "Cultural Workshop",
        description: "Participate in a workshop to learn traditional crafts",
        type: "Cultural",
      },
    ],
    "Food & Cuisine": [
      { title: "Food Tour", description: "Sample local delicacies on a guided food tour", type: "Food" },
      {
        title: "Cooking Class",
        description: "Learn to prepare traditional dishes with local ingredients",
        type: "Food",
      },
      { title: "Fine Dining Experience", description: "Enjoy a gourmet meal at a renowned restaurant", type: "Food" },
    ],
    "Adventure & Sports": [
      {
        title: "Zip-lining Adventure",
        description: "Experience an adrenaline-pumping zip-line course",
        type: "Adventure",
      },
      { title: "Water Sports", description: "Try kayaking, paddleboarding, or surfing", type: "Adventure" },
      { title: "Mountain Biking", description: "Explore rugged terrain on mountain bikes", type: "Adventure" },
    ],
  }

  // Generate 3-4 activities for the day
  const activities = []
  const times = ["9:00 AM", "12:00 PM", "3:00 PM", "7:00 PM"]
  const durations = ["2 hours", "1.5 hours", "3 hours", "2 hours"]

  // Select activities based on interests or default to a mix
  const selectedInterests = interests && interests.length > 0 ? interests : Object.keys(activityTypes)

  for (let i = 0; i < 4; i++) {
    // Rotate through interests for variety
    const interestIndex = (day + i) % selectedInterests.length
    const interestKey =
      selectedInterests[interestIndex] || Object.keys(activityTypes)[i % Object.keys(activityTypes).length]

    // Get activities for this interest
    const interestActivities =
      activityTypes[interestKey as keyof typeof activityTypes] || activityTypes["Nature & Outdoors"]

    // Select an activity
    const activityIndex = (day + i) % interestActivities.length
    const activity = interestActivities[activityIndex]

    activities.push({
      time: times[i],
      title: activity.title,
      description: activity.description,
      location: "Local Area",
      duration: durations[i],
      type: activity.type,
    })
  }

  return activities
}
